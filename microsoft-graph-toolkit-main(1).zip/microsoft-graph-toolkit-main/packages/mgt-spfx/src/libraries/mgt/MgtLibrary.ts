export class MgtLibrary {
  public name(): string {
    return 'MgtLibrary';
  }
}
