import Main from './main';
Main.main();
