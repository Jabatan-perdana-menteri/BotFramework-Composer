export interface IMgtDemoProps {
  description: string;
}
