declare interface IMgtDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'MgtDemoWebPartStrings' {
  const strings: IMgtDemoWebPartStrings;
  export = strings;
}
