## TeamsFx app using Microsoft Graph Toolkit components

You can find the best TeamsFx sample app using Microsoft Graph Toolkit components on the TeamsFx repo. Click [here](https://github.com/OfficeDev/TeamsFx-Samples/tree/dev/graph-toolkit-contact-exporter) to be redirected.

![Contact Exporter Sample](https://github.com/OfficeDev/TeamsFx-Samples/raw/dev/graph-toolkit-contact-exporter/images/overview.gif)