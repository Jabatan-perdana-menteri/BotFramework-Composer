---
name: Support Question
about: Question on how to use this project
title: "[QUESTION]"
labels: ''
assignees: ''

---

# Support Question

Please do not submit support requests or "How to" questions here. Instead, please use [Stack Overflow](https://stackoverflow.com/questions/tagged/microsoft-graph-toolkit) where questions should be tagged with the tag `microsoft-graph-toolkit`

This issue will be closed
