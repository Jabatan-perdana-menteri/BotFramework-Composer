export const CLIENTID = 'ac77046c-156c-40f0-8507-3b5a58034582';
export const GETPROVIDER_EVENT = 'mgt/getProvider';
export const SETPROVIDER_EVENT = 'mgt/setProvider';
